package Patterns;

public class Pattern1_7
{
	public static void main(String[] args) 
	{
		for(int i=2; i<=10; i+=2)
		{
			System.out.println(i);
		}
	}
}

//Output:
//2
//4
//6
//8
//10	